Page({
  data: {
    categories: [
      { id: 1, name: "美食" },
      { id: 2, name: "甜点饮品" },
      { id: 1, name: "超市便利" },
      { id: 2, name: "蔬菜水果" },
      { id: 3, name: "看病买药" },
      { id: 1, name: "午餐" },
      { id: 2, name: "拼好饭" },
      { id: 3, name: "跑腿" }
    ],
    shops: [
      { id: 101, name: "小龙虾店", distance: "1.2km", sales: "月售100单", logo: "/images/rider.png" },
      { id: 102, name: "川菜馆", distance: "2.5km", sales: "月售80单", logo: "/images/rider.png" },
      { id: 103, name: "披萨店", distance: "800m", sales: "月售120单", logo: "/images/rider.png" },
      { id: 104, name: "麦当劳", distance: "800m", sales: "月售1999单", logo: "/images/rider.png" },
      { id: 105, name: "茶百道", distance: "800m", sales: "月售120单", logo: "/images/rider.png" },
      { id: 106, name: "新疆炒米粉", distance: "800m", sales: "月售120单", logo: "/images/rider.png" },
    ],
    searchInputValue: '',
    filteredShops: []
  },
  onLoad: function () {
    // 页面加载时默认显示所有店铺
    this.setData({
      filteredShops: this.data.shops
    });
  },
  // 搜索输入框输入事件
  onSearchInput: function (e) {
    const value = e.detail.value.trim();
    this.setData({
      searchInputValue: value
    });
    this.filterShops(value);
  },
  // 根据搜索关键词过滤店铺
  filterShops: function (keyword) {
    const shops = this.data.shops;
    const filteredShops = shops.filter(shop => {
      return shop.name.includes(keyword);
    });
    this.setData({
      filteredShops: filteredShops
    });
  },
  // 清空搜索框
  clearSearchInput: function () {
    this.setData({
      searchInputValue: '',
      filteredShops: this.data.shops
    });
  },
  navigateToShop: function(event) {
    const shopId = event.currentTarget.dataset.shopId;
    wx.navigateTo({
      url: `/pages/shopDetail/shopDetail?id=${shopId}`
    });
  }
  // 其他自定义方法
});
