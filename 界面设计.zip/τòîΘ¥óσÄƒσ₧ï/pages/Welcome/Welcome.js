Page({
  goToIndex: function() {
    wx.switchTab({
      url: '/pages/home/home'
    });
  }
});
