// pages/mine/mine.js

Page({
  data: {
    isLogged: false,
    userInfo: null
  },
  onLoad: function () {
    // 页面加载时检查用户是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        userInfo: JSON.parse(userInfo),
        isLogged: true
      });
    }
  },
  
  // 微信一键登录
  login: function () {
    wx.getUserProfile({
      desc: '用于完善会员资料',
      success: (res) => {
        const userInfo = {
          nickName: res.userInfo.nickName,
          avatarUrl: res.userInfo.avatarUrl
        };
        wx.setStorageSync('userInfo', JSON.stringify(userInfo));
        this.setData({
          userInfo: userInfo,
          isLogged: true
        });
        wx.showToast({
          title: '登录成功',
          icon: 'success',
          duration: 2000
        });
      },
      fail: (err) => {
        console.log('获取用户信息失败', err);
      }
    });
  },

  // 退出登录
  logout: function () {
    wx.removeStorageSync('userInfo');
    this.setData({
      userInfo: null,
      isLogged: false
    });
    wx.showToast({
      title: '退出登录成功',
      icon: 'success',
      duration: 2000
    });
  },

  // 其他自定义方法
});
