// pages/order/order.js

Page({
  data: {
    orders: [
      { orderId: "2024001", date: "2024-06-30 10:30", total: "88.00", status: "待支付" },
      { orderId: "2024002", date: "2024-06-29 15:45", total: "55.50", status: "已支付" },
      { orderId: "2024003", date: "2024-06-28 09:00", total: "120.00", status: "已完成" },
      // 可根据需要添加更多订单数据
    ]
  },
  onLoad: function () {
    // 页面加载时处理逻辑
  },
  
  // 点击订单项跳转到订单详情页面
  viewOrderDetail: function (e) {
    const order = e.currentTarget.dataset.order;
    wx.navigateTo({
      url: '/pages/orderDetail/orderDetail?orderId=' + order.orderId + '&date=' + order.date + '&total=' + order.total + '&status=' + order.status
    });
  },

  // 其他自定义方法
});
