// pages/orderDetail/orderDetail.js
Page({
  data: {
    order: {
      id: '1234567890',
      status: '已完成',
      purchaseTime: '2023-06-26 12:00',
      address: '北京市海淀区XXX路XXX号',
      totalAmount: 130,
      products: [
        { id: 1, name: "商品1", price: 10, quantity: 2, subtotal: 20, image: "/images/rider.png" },
        { id: 2, name: "商品2", price: 20, quantity: 1, subtotal: 20, image: "/images/rider.png" },
        { id: 3, name: "商品3", price: 30, quantity: 3, subtotal: 90, image: "/images/rider.png" }
      ]
    }
  }
});
