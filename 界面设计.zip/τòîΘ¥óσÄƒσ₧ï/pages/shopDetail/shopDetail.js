Page({
  data: {
    shopName: '示例店铺',
    shopDescription: '这是一个示例店铺的简介。',
    products: [
      { id: 1, name: "商品1", price: 10, quantity: 0, subtotal: 0, image: "/images/rider.png" },
      { id: 2, name: "商品2", price: 20, quantity: 0, subtotal: 0, image: "/images/rider.png" },
      { id: 3, name: "商品3", price: 30, quantity: 0, subtotal: 0, image: "/images/rider.png" }
    ],
    totalPrice: 0,
    showCartPopup: false,  // 控制购物车弹出框显示与隐藏
    selectedProducts: []   // 已选择的商品列表
  },
  onLoad: function(options) {
    this.calculateTotalPrice();
  },
  increaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const products = this.data.products.map(product => {
      if (product.id === id) {
        product.quantity += 1;
        product.subtotal = product.quantity * product.price;
      }
      return product;
    });
    this.setData({ products });
    this.calculateTotalPrice();
  },
  decreaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const products = this.data.products.map(product => {
      if (product.id === id && product.quantity > 0) {
        product.quantity -= 1;
        product.subtotal = product.quantity * product.price;
      }
      return product;
    });
    this.setData({ products });
    this.calculateTotalPrice();
  },
  calculateTotalPrice: function() {
    const totalPrice = this.data.products.reduce((total, product) => {
      return total + product.subtotal;
    }, 0);
    this.setData({ totalPrice });
  },
  showCart: function() {
    // 选取购物车中数量大于0的商品
    const selectedProducts = this.data.products.filter(product => product.quantity > 0);
    this.setData({ showCartPopup: true, selectedProducts });
  },
  closeCart: function() {
    this.setData({ showCartPopup: false });
  }
});
